package com.intellig_shiksha.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.intellig_shiksha.dao.QuizDao;
import com.intellig_shiksha.entities.Quiz;
import com.intellig_shiksha.util.HibernateUtil;

public class QuizDaoImpl implements QuizDao {

    @Override
    public void saveQuiz(Quiz quiz) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.save(quiz);
            tx.commit();
            System.out.println("Quiz saved " + quiz.getTitle());
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public Quiz getQuizById(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Quiz.class, id);
        }
    }

    @Override
    public List<Quiz> getAllQuizzes() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Quiz", Quiz.class).list();
        }
    }

    @Override
    public void updateQuiz(Quiz quiz) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.update(quiz);
            tx.commit();
            System.out.println("Quiz updated ID " + quiz.getQuizId());
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteQuiz(Quiz quiz) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.delete(quiz);
            tx.commit();
            System.out.println("Quiz deleted with ID " + quiz.getQuizId());
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }
}
