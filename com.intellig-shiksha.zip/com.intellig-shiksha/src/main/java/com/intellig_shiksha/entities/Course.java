package com.intellig_shiksha.entities;

import javax.persistence.*;

@Entity
@Table(name = "courseDetails")
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "courseId")
    private int courseId;

    @Column(name = "courseName",unique = true, length = 50, nullable = false)
    private String courseName;

    @Column(name = "title", length = 100, nullable = false)
    private String title;

    @Column(name = "description", length = 1000, nullable = false)
    private String description;

    @Column(name = "category", length = 1024)
    private String category;

    @Column(name = "durationInHours")
    private int durationInHours;

    @Column(name = "level", length = 100)
    private String level;

    
    @ManyToOne
    @JoinColumn(name = "teacher_id") // This is the foreign key in course table
    private Teachers teacher;

//    @ManyToOne
//    @JoinColumn(name="student_id")
//    private Students student;
    
    //No-arg constructor
    public Course() {
    }

    // Parameterized constructor
	public Course(int courseId, String courseName, String title, String description, String category,
			int durationInHours, String level, Teachers teacher, Students student) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.title = title;
		this.description = description;
		this.category = category;
		this.durationInHours = durationInHours;
		this.level = level;
		this.teacher = teacher;
//		this.student = student;
	}

	// Getters and setters
	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getDurationInHours() {
		return durationInHours;
	}

	public void setDurationInHours(int durationInHours) {
		this.durationInHours = durationInHours;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public Teachers getTeacher() {
		return teacher;
	}

	public void setTeacher(Teachers teacher) {
		this.teacher = teacher;
	}

//	public Students getStudent() {
//		return student;
//	}
//
//	public void setStudent(Students student) {
//		this.student = student;
//	}

	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", courseName=" + courseName + ", title=" + title + ", description="
				+ description + ", category=" + category + ", durationInHours=" + durationInHours + ", level=" + level
				+ ", teacher=" + teacher + ", student=" + "]";
	}

}
