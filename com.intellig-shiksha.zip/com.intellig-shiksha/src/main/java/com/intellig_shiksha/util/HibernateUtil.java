package com.intellig_shiksha.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.intellig_shiksha.entities.Course;
import com.intellig_shiksha.entities.ExamAndResult;
import com.intellig_shiksha.entities.Teachers;
import com.intellig_shiksha.entities.Students;
import com.intellig_shiksha.entities.Quiz;
import com.intellig_shiksha.entities.Authentication;

public class HibernateUtil {
    private static final SessionFactory sessionFactory;

    static {
        try {
            // Create Configuration instance and load the config.xml
            Configuration configuration = new Configuration();
            configuration.configure("/com/is/config/config.xml"); // add '/' to ensure correct classpath loading

            // Add all annotated classes
            configuration.addAnnotatedClass(Course.class);
            configuration.addAnnotatedClass(Teachers.class);
            configuration.addAnnotatedClass(Students.class);
            configuration.addAnnotatedClass(Quiz.class);
            configuration.addAnnotatedClass(Authentication.class);
            configuration.addAnnotatedClass(ExamAndResult.class);

            // Build the SessionFactory
            sessionFactory = configuration.buildSessionFactory();
        } catch (Throwable ex) {
            System.err.println("Initial SessionFactory creation failed: " + ex);
            ex.printStackTrace();
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}
