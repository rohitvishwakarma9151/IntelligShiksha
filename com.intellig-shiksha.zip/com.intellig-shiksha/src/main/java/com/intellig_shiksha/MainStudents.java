//package com.intellig_shiksha;
//
//import com.intellig_shiksha.entities.Students;
//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
//import org.hibernate.cfg.Configuration;
//
//import java.time.LocalDate;
//
//public class MainStudents {
//    public static void main(String[] args) {
//
//        // Load configuration and build session factory
//        Configuration cfg = new Configuration();
//        cfg.configure("com/is/config/hibernate.cfg.xml"); // adjust path if needed
//        cfg.addAnnotatedClass(Students.class);
//
//        SessionFactory factory = cfg.buildSessionFactory();
//
//        // Open session and begin transaction
//        Session session = factory.openSession();
//        session.beginTransaction();
//
//        // Create and save student object
//        Students student = new Students();
//        student.setName("John Doe");
//        student.setEmail("john.doe@example.com");
//        student.setPhone("9876543210");
//        student.setGender("Male");
//        student.setAddress("123 Main Street");
//        student.setDob(LocalDate.of(2000, 5, 15));
//        student.setCourseEnrolled("Java Full Stack");
//
//        session.save(student); // Save to DB
//
//        // Commit transaction and close session
//        session.getTransaction().commit();
//        session.close();
//        factory.close();
//
//        System.out.println("Student data saved successfully!");
//    }
//}
