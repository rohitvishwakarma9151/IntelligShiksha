package com.intellig_shiksha.dao;

import java.util.List;

import com.intellig_shiksha.entities.Quiz;

public interface QuizDao {
	
	// Saves a new quiz to the database
	void saveQuiz (Quiz quiz);
	
	// Retrieves a quiz by its unique identifier
	Quiz getQuizById (int id);
	
	// Returns a list of all quizzes in the database
	List<Quiz> getAllQuizzes();
	
	// Updates an existing quiz in the database
	void updateQuiz (Quiz quiz);
	
	// Deletes a specified quiz from the database
	void deleteQuiz (Quiz quiz);

}
