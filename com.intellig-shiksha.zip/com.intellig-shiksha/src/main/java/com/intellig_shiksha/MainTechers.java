//package com.intellig_shiksha;
//
//import com.intellig_shiksha.dao.TeacherDao;
//import com.intellig_shiksha.daoimpl.TeacherDaoImpl;
//import com.intellig_shiksha.entities.Teachers;
//
//public class MainTechers {
//    public static void main(String[] args) {
//    	
//        System.out.println("Project started!");
//        
//        TeacherDao dao=new TeacherDaoImpl();
//        
//        // Insert
//        Teachers t1 = new Teachers();
//        t1.setTeacherId(123);
//        t1.setName("Dr. Aryan Sharma");
//        t1.setEmail("aryan.sharma@example.com");
//        t1.setPhone("9876543210");
//        t1.setQualification("PhD");
//        t1.setSpecialization("Machine Learning");
//        t1.setExpertise("AI");
//        dao.insertTeacher(t1);
//        
//        // Fetch by ID
//        Teachers t2 = dao.getTeacherById(1154);
//        if (t2 != null) {
//            t2.setPhone("1234567890");
//            dao.updateTeacher(t2);
//            System.out.println("Upadated phone number is : "+t2);
//        } else {
//            System.out.println("Teacher with ID 1 not found.");
//        }
//
//        // Update
////        t2.setPhone("9998887776");
////        dao.updateTeacher(t2);
//
//        // Delete
//        dao.deleteTeacher(11); // assumes teacher with id=2 exists
//        System.out.println("Deleted id is " +dao);
//        
//    }
//}
