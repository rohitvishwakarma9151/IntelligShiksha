package com.intellig_shiksha.dao;

import com.intellig_shiksha.entities.Students;
import java.util.List;

public interface StudentDao {
	
	void addStudent(Students student);
    void saveStudent(Students student);
    Students getStudentById(int id);
    List<Students> getAllStudents();
    void updateStudent(Students student);
    void deleteStudent(int id);  // This is the method that must be implemented
    void enrollStudentToCourse(String email, String courseName);

}
