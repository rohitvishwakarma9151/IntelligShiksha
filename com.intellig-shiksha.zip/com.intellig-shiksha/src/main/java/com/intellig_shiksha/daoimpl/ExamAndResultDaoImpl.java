package com.intellig_shiksha.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.intellig_shiksha.dao.ExamAndResultDao;
import com.intellig_shiksha.entities.ExamAndResult;

public class ExamAndResultDaoImpl implements ExamAndResultDao{
	
	private SessionFactory factory;

	@Override
	public void saveExamResult(ExamAndResult result) {
		
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(result);
		tx.commit();
		session.close();
		
	}

	@Override
	public ExamAndResult getExamResultById(int resultId) {
		
		Session session=factory.openSession();
		ExamAndResult result=session.get(ExamAndResult.class, resultId);
		session.close();
		return result;
	}

	@Override
	public List<ExamAndResult> getAllExamResults() {
		
		Session session=factory.openSession();
		 List<ExamAndResult> results = session.createQuery("from ExamAndResult", ExamAndResult.class).list();
		 session.close();
		 return null;
	}

	@Override
	public void updateExamResult(ExamAndResult result) {
		
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		session.update(result);
		tx.commit();
		session.close();
		
	}

	@Override
	public void deleteExamResult(int resultId) {
		
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		ExamAndResult result2=session.get(ExamAndResult.class, resultId);
		if(result2 != null) {
			session.delete(result2);
		}
		tx.commit();
		session.close();
		
	}

}
