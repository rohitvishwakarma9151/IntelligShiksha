package com.intellig_shiksha.dao;

import java.util.List;

import com.intellig_shiksha.entities.ExamAndResult;
import com.intellig_shiksha.entities.Teachers;

public interface TeacherDao {
	
	    void insertTeacher(Teachers teacher);
	    Teachers getTeacherById(int id);
	    List<Teachers> getAllTeachers();
	    void updateTeacher(Teachers teacher);
	    void deleteTeacher(int id);
	
}