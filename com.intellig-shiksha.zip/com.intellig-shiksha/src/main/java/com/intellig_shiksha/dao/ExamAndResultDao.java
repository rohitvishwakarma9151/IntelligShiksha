package com.intellig_shiksha.dao;

import java.util.List;

import com.intellig_shiksha.entities.ExamAndResult;

public interface ExamAndResultDao {
	
	void saveExamResult(ExamAndResult result);

    ExamAndResult getExamResultById(int resultId);

    List<ExamAndResult> getAllExamResults();

    void updateExamResult(ExamAndResult result);

    void deleteExamResult(int resultId);

}
