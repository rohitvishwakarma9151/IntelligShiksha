package com.intellig_shiksha.dao;

import java.util.List;

import com.intellig_shiksha.entities.Course;

public interface CourseDao {
	
	void addCourse(Course course);
    void updateCourse(Course course);
    void deleteCourse(int courseId);
    Course getCourseById(int courseId);
    List<Course> getAllCourses();

}
