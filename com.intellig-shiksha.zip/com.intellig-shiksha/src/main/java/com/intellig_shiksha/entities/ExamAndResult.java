package com.intellig_shiksha.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "exam_and_result")
public class ExamAndResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "result_id")
    private int resultId;

    @Column(name = "student_id", nullable = false)
    private int studentId;

    @Column(name = "course_id", nullable = false)
    private int courseId;

    @Column(name = "exam_type", nullable = false)
    private String examType;

    @Column(name = "total_marks")
    private int totalMarks;

    @Column(name = "obtained_marks")
    private int obtainedMarks;

    @Column(name = "result_status")
    private String resultStatus;

    @Column(name = "exam_date")
    private String examDate;

    // Constructors
    public ExamAndResult() {}

    public ExamAndResult(int studentId, int courseId, String examType, int totalMarks, int obtainedMarks, String resultStatus, String examDate) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.examType = examType;
        this.totalMarks = totalMarks;
        this.obtainedMarks = obtainedMarks;
        this.resultStatus = resultStatus;
        this.examDate = examDate;
    }

    // Getters and Setters

    public int getResultId() {
        return resultId;
    }

    public void setResultId(int resultId) {
        this.resultId = resultId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getExamType() {
        return examType;
    }

    public void setExamType(String examType) {
        this.examType = examType;
    }

    public int getTotalMarks() {
        return totalMarks;
    }

    public void setTotalMarks(int totalMarks) {
        this.totalMarks = totalMarks;
    }

    public int getObtainedMarks() {
        return obtainedMarks;
    }

    public void setObtainedMarks(int obtainedMarks) {
        this.obtainedMarks = obtainedMarks;
    }

    public String getResultStatus() {
        return resultStatus;
    }

    public void setResultStatus(String resultStatus) {
        this.resultStatus = resultStatus;
    }

    public String getExamDate() {
        return examDate;
    }

    public void setExamDate(String examDate) {
        this.examDate = examDate;
    }
}
