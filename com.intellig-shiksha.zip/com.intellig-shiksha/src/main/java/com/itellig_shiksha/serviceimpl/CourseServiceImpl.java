package com.itellig_shiksha.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.intellig_shiksha.dao.CourseDao;
import com.intellig_shiksha.entities.Course;
import com.intellig_shiksha.service.CourseService;

public class CourseServiceImpl implements CourseService{
	
	@Autowired
	private CourseDao courseDao;

	@Override
	public Course createCourse(Course course) {
		
		return null;
	}

	@Override
	public Course getCourseById(int courseId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Course> getAllCourses() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Course updateCourse(Course course) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteCourse(int courseId) {
		// TODO Auto-generated method stub
		
	}

}
