//package com.intellig_shiksha;
//
//import java.util.ArrayList;
//
//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
//import org.hibernate.Transaction;
//import org.hibernate.cfg.Configuration;
//
//import com.intellig_shiksha.entities.Course;
//import com.intellig_shiksha.entities.Teachers;
//
//public class OneToManyMapping {
//    public static void main(String[] args) {
//        System.out.println("Project started!");
//
//        // Set up Hibernate session factory
//        Configuration cfg = new Configuration();
//        cfg.configure("/com/is/config/config.xml"); // Make sure path is correct
//        SessionFactory factory = cfg.buildSessionFactory();
//
//        // Create Teacher object
//        Teachers teacher = new Teachers();
//        teacher.setName("Dr. Rajesh Kumar");
//        teacher.setEmail("rajesh.kumar@techuniversity.com");
//        teacher.setExpertise("Full Stack Development");
//        teacher.setPhone("9876543210");
//        teacher.setQualification("M.Tech in Software Engineering, Ph.D. in Computer Science");
//
//        // Create Course objects
//        Course crs = new Course();
//        crs.setCourseName("Advanced Python Full Stack");
//        crs.setCategory("Advanced Python\nData Structures\nAlgorithms\nWeb Development with Django and Flask");
//        crs.setDescription("In-depth study of advanced Python concepts, frameworks, and real-world project development.");
//        crs.setTitle("Advanced Full Stack Web Development with Python");
//        crs.setLevel("Intermediate / Advanced");
//        crs.setDurationInHours(90);
//        crs.setTeacher(teacher); // Set the teacher
//
//        Course crs1 = new Course();
//        crs1.setCourseName("Java Full Stack Development");
//        crs1.setCategory("Core Java\nSpring Framework\nDatabase Integration\nFront-end with React");
//        crs1.setDescription("Comprehensive Java development course focusing on both front-end and back-end.");
//        crs1.setTitle("Full Stack Web Development with Java and React");
//        crs1.setLevel("Intermediate / Advanced");
//        crs1.setDurationInHours(85);
//        crs1.setTeacher(teacher); // Set the teacher
//
//        // Associate courses with the teacher
//        ArrayList<Course> courses = new ArrayList<>();
//        courses.add(crs);
//        courses.add(crs1);
//        teacher.setCourses(courses);
//
//        // Hibernate session and transaction
//        Session session = factory.openSession();
//        Transaction tx = session.beginTransaction();
//
//        // Save only teacher (cascade will save courses if configured)
//        session.save(teacher);
//
//
//        // session.save(crs);
//        // session.save(crs1);
//
//        tx.commit();
//        session.close();
//        factory.close();
//
//        System.out.println("Project completed!");
//    }
//}
