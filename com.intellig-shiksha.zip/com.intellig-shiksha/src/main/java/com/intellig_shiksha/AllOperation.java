package com.intellig_shiksha;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.hibernate.query.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.intellig_shiksha.entities.Authentication;
import com.intellig_shiksha.entities.Course;
import com.intellig_shiksha.entities.ExamAndResult;
import com.intellig_shiksha.entities.Quiz;
import com.intellig_shiksha.entities.Students;
import com.intellig_shiksha.entities.Teachers;

public class AllOperation {

    public static void main(String[] args) {
        
        System.out.println("Welcome to IntelliShiksha");

        Scanner sc = new Scanner(System.in);

        // Hibernate configuration
        Configuration cfg = new Configuration();
        cfg.configure("/com/is/config/config.xml");
        SessionFactory factory = cfg.buildSessionFactory();
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();

        while (true) {
            // Menu for User Input
            System.out.println("\nSelect an operation:");
            System.out.println("1. Insert Authentication");
            System.out.println("2. Insert Student");
            System.out.println("3. Insert Teacher and Courses");
            System.out.println("4. Insert Quiz");
            System.out.println("5. Insert Exam and Result");
            System.out.println("6. Exit");
            System.out.print("Enter your choice (1-6): ");
            
            int choice = Integer.parseInt(sc.nextLine());

            try {
                switch (choice) {
                    case 1:
                        // 1. Insert Authentication
                        System.out.println("\n--- Authentication Details ---");
                        Authentication auth = new Authentication();
                        System.out.print("Enter Email: ");
                        auth.setEmail(sc.nextLine());
                        System.out.print("Enter Password: ");
                        auth.setPassword(sc.nextLine());
                        System.out.print("Enter Role (Student/Teacher): ");
                        auth.setRole(sc.nextLine());
                        session.save(auth);
                        System.out.println("Authentication saved.");
                        break;

                    case 2: {
                        // 2. Insert Student
                        System.out.println("\n--- Student Details ---");
                        Students student = new Students();
                        System.out.print("Enter Student Name: ");
                        student.setName(sc.nextLine());
                        System.out.print("Enter Email: ");
                        student.setEmail(sc.nextLine());
                        System.out.print("Enter Phone: ");
                        student.setPhone(sc.nextLine());
                        System.out.print("Enter Gender: ");
                        student.setGender(sc.nextLine());
                        System.out.print("Enter Address: ");
                        student.setAddress(sc.nextLine());
                        System.out.print("Enter Date of Birth (yyyy-mm-dd): ");
                        student.setDob(LocalDate.parse(sc.nextLine()));

                        // Fetch Course from DB
                        System.out.print("Enter Course Enrolled (Course Name): ");
                        String courseNameInput = sc.nextLine();
                        Query<Course> courseQuery = session.createQuery("FROM Course WHERE courseName = :name", Course.class);
                        courseQuery.setParameter("name", courseNameInput);
                        List<Course> courseList = courseQuery.getResultList();

                        if (courseList.isEmpty()) {
                            throw new RuntimeException("Course not found with name: " + courseNameInput);
                        }

                        Course course = courseList.get(0);

                        // Set both Course object and courseEnrolled field
                        student.setCourse(course);
                        student.setCourseEnrolled(course.getCourseName());

                        session.save(student);
                        System.out.println("Student saved.");
                        break;
                    }


                    case 3:
                        // 3. Insert Teacher + Courses
                        System.out.println("\n--- Teacher and Courses Details ---");
                        Teachers teacher = new Teachers();
                        System.out.print("Enter Teacher Name: ");
                        teacher.setName(sc.nextLine());
                        System.out.print("Enter Email: ");
                        teacher.setEmail(sc.nextLine());
                        System.out.print("Enter Phone: ");
                        teacher.setPhone(sc.nextLine());
                        System.out.print("Enter Qualification: ");
                        teacher.setQualification(sc.nextLine());
                        System.out.print("Enter Specialization: ");
                        teacher.setSpecialization(sc.nextLine());
                        System.out.print("Enter Expertise: ");
                        teacher.setExpertise(sc.nextLine());

                        System.out.print("How many courses to add for this teacher? ");
                        int n = Integer.parseInt(sc.nextLine());
                        ArrayList<Course> courseList = new ArrayList<>();
                        for (int i = 1; i <= n; i++) {
                            System.out.println("Enter details for Course #" + i);
                            Course course1 = new Course();
                            System.out.print("Course Name: ");
                            course1.setCourseName(sc.nextLine());
                            System.out.print("Category: ");
                            course1.setCategory(sc.nextLine());
                            System.out.print("Description: ");
                            course1.setDescription(sc.nextLine());
                            System.out.print("Title: ");
                            course1.setTitle(sc.nextLine());
                            System.out.print("Level: ");
                            course1.setLevel(sc.nextLine());
                            System.out.print("Duration (in hours): ");
                            course1.setDurationInHours(Integer.parseInt(sc.nextLine()));

                            course1.setTeacher(teacher); // set teacher in course
                            courseList.add(course1);
                        }
                        teacher.setCourses(courseList);
                        session.save(teacher); // will automatically save courses due to Cascade
                        System.out.println("Teacher and their Courses saved.");
                        break;

                    case 4:
                        // 4. Insert Quiz
                        System.out.println("\n--- Quiz Details ---");
                        Quiz quiz = new Quiz();
                        System.out.print("Quiz Title: ");
                        quiz.setTitle(sc.nextLine());
                        System.out.print("Course ID (Integer): ");
                        quiz.setCourseId(sc.nextLine());
                        System.out.print("Scheduled Date (yyyy-mm-dd): ");
                        quiz.setDateScheduled(sc.nextLine());
                        session.save(quiz);
                        System.out.println("Quiz saved.");
                        break;

                    case 5:
                        // 5. Insert ExamAndResult
                        System.out.println("--- Exam and Result Details ---");
                        ExamAndResult examResult = new ExamAndResult();
                        System.out.print("Student ID: ");
                        examResult.setStudentId(Integer.parseInt(sc.nextLine()));
                        System.out.print("Course ID: ");
                        examResult.setCourseId(Integer.parseInt(sc.nextLine()));
                        System.out.print("Exam Type (e.g., Mid-Term, Final): ");
                        examResult.setExamType(sc.nextLine());
                        System.out.print("Total Marks: ");
                        examResult.setTotalMarks(Integer.parseInt(sc.nextLine()));
                        System.out.print("Obtained Marks: ");
                        examResult.setObtainedMarks(Integer.parseInt(sc.nextLine()));
                        System.out.print("Result Status (Pass/Fail): ");
                        examResult.setResultStatus(sc.nextLine());
                        System.out.print("Exam Date (yyyy-mm-dd): ");
                        examResult.setExamDate(sc.nextLine());
                        session.save(examResult);
                        System.out.println("Exam Result saved.");
                        break;

                    case 6:
                        // Exit
                        tx.commit();
                        System.out.println("All Data Saved Successfully!");
                        session.close();
                        factory.close();
                        sc.close();
                        System.out.println("Session and Factory closed.");
                        return; // Exit the program

                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (Exception e) {
                tx.rollback();
                System.err.println("Error during transaction: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}
