//package com.intellig_shiksha;
//
//import com.intellig_shiksha.entities.ExamAndResult;
//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
//import org.hibernate.Transaction;
//import org.hibernate.cfg.Configuration;
//
//import java.util.List;
//
//public class MainExamAndResult {
//    public static void main(String[] args) {
//
//        System.out.println("Exam & Result");
//
//        // Create configuration
//        Configuration cfg = new Configuration();
//        cfg.configure("/com/is/config/config.xml"); // Ensure this is placed correctly
//        cfg.addAnnotatedClass(ExamAndResult.class);
//
//        // Build session factory
//        SessionFactory factory = cfg.buildSessionFactory();
//
//        // Open session
//        Session session = factory.openSession();
//
//        // Start transaction
//        Transaction tx = session.beginTransaction();
//        
//
//        // Create and save a  ExamAndResult-1 record
//        ExamAndResult result = new ExamAndResult(
//                101,        // studentId
//                501,        // courseId
//                "Final",    // examType
//                100,        // totalMarks
//                85,         // obtainedMarks
//                "Pass",     // resultStatus
//                "2025-04-12" // examDate
//        );
//        
//      //Create and save a new ExamAndResult-2 record
//        ExamAndResult result1 = new ExamAndResult(
//        		102,                // studentId
//                101,              // courseId
//                "Mid-Term",       // examType
//                100,              // totalMarks
//                88,               // obtainedMarks
//                "Pass",           // resultStatus
//                "2025-04-21"      // examDate
//        );
//        
//        
//      //Create and save a new ExamAndResult-2 record
//        ExamAndResult result2 = new ExamAndResult(
//        		103,                // studentId
//                101,              // courseId
//                "Mid-Term",       // examType
//                100,              // totalMarks
//                72,               // obtainedMarks
//                "Pass",           // resultStatus
//                "2025-04-26"      // examDate
//        );
//
//        session.save(result);
//        session.save(result1);
//        session.save(result2);
//        System.out.println("Exam result saved!");
//
//        // Optional: Fetch and display all records
////        List<ExamAndResult> results = session.createQuery("from ExamAndResult", ExamAndResult.class).list();
////        System.out.println("All Exam Results:");
////        for (ExamAndResult r : results) {
////            System.out.println("ResultID: " + r.getResultId() + ", StudentID: " + r.getStudentId()
////                    + ", CourseID: " + r.getCourseId() + ", Marks: " + r.getObtainedMarks());
////        }
//
//        // Commit transaction
//        tx.commit();
//
//        // Close session and factory
//        session.close();
//        factory.close();
//
//        System.out.println("Operation completed successfully!");
//    }
//}
