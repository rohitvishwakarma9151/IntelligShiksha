package com.intellig_shiksha.entities;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "TeacherDetails")
public class Teachers {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "teacherId")
    private int teacherId;

    @Column(name = "name", length = 50, nullable = false)
    private String name;

    @Column(name = "email", length = 50, nullable = false)
    private String email;

    @Column(name = "phone", length = 20)
    private String phone;

    @Column(name = "qualification", length = 100)
    private String qualification;

    @Column(name = "specialization", length = 100)
    private String specialization;

    @Column(name = "expertise", length = 200, nullable = false)
    private String expertise;

    // One-to-many relationship with Course entity
    @OneToMany(mappedBy = "teacher", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Course> courses;

    //No-arg constructor 
    public Teachers() {
    }

    // parameterized constructor
    public Teachers(String name, String email, String phone, String qualification,
                    String specialization, String expertise) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.qualification = qualification;
        this.specialization = specialization;
        this.expertise = expertise;
    }

    // Getters and Setters

    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getExpertise() {
        return expertise;
    }

    public void setExpertise(String expertise) {
        this.expertise = expertise;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

    //
    @Override
    public String toString() {
        return "Teachers [teacherId=" + teacherId + ", name=" + name + ", email=" + email + ", phone=" + phone
                + ", qualification=" + qualification + ", specialization=" + specialization + ", expertise=" + expertise
                + "]";
    }
}
