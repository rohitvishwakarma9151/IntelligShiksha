package com.intellig_shiksha.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
//import org.hibernate.cfg.Configuration;

import com.intellig_shiksha.dao.AuthenticationDao;
import com.intellig_shiksha.entities.Authentication;
import com.intellig_shiksha.util.HibernateUtil;

public class AuthenticationDaoImpl implements AuthenticationDao{
	
	private SessionFactory factory;
	
	// Proper constructor
    public AuthenticationDaoImpl() {
        this.factory = HibernateUtil.getSessionFactory();
    }



	@Override
	public void registerUser(Authentication auth) {

		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(auth);
		tx.commit();
		session.close();
		
	}

	@Override
	public Authentication login(String email, String password) {
		
		Session session=factory.openSession();
		Authentication auth=session.createQuery("From Authentication where email = :email and password = :password", Authentication.class).setParameter("email", email).setParameter("password", password).uniqueResult();
	    session.close();
		return auth;
	}

	@Override
	public void updatePassword(String email, String newPassword) {
		
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		Authentication auth=session.createQuery("From Authentication where email = :email", Authentication.class).setParameter("email", email).uniqueResult();
		if(auth != null) {
			auth.setPassword(newPassword);
			session.update(auth);
		}
		
	}

	@Override
	public void deleteUser(String email) {
		
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		Authentication auth=session.createQuery("From Authentication where email = :email", Authentication.class).setParameter("email", email).uniqueResult();
		if(auth != null) {
			session.delete(auth);
		}
		tx.commit();
		session.close();
		
	}

	@Override
	public Authentication getUserByEmail(String email) {
		
		Session session=factory.openSession();
		Authentication auth=session.createQuery("From Authentication where email = :email", Authentication.class).setParameter("email", email).uniqueResult();
		
		session.close();
		return auth;
	}

	@Override
	public List<Authentication> getAllUsers() {
		
	    Session session = factory.openSession();
	    List<Authentication> users = session.createQuery("From Authentication", Authentication.class).list();
	    session.close();
	    return users;
	    
	}

}
