package com.intellig_shiksha.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Quiz")
public class Quiz {
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int quizId;
	
	@Column(nullable=false)
	private String title;
	
	@Column(nullable=false)
	private String courseId;
	
	@Column(nullable=false)
	private String dateScheduled;
	
	public Quiz() {}

	public Quiz(int quizId, String title, String courseId, String dateScheduled) {
		super();
		this.quizId = quizId;
		this.title = title;
		this.courseId = courseId;
		this.dateScheduled = dateScheduled;
	}

	public int getQuizId() {
		return quizId;
	}

	public void setQuizId(int quizId) {
		this.quizId = quizId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public String getDateScheduled() {
		return dateScheduled;
	}

	public void setDateScheduled(String dateScheduled) {
		this.dateScheduled = dateScheduled;
	}
	
	

}
