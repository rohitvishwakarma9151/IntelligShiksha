//package com.intellig_shiksha;
//
//import java.util.List;
//
//import org.hibernate.Session;
//import org.hibernate.Transaction;
//
//import com.intellig_shiksha.entities.Quiz;
//import com.intellig_shiksha.util.HibernateUtil;
//
//public class MainQuiz {
//    
//    public static void main(String[] args) {
//        // Create a new Quiz object
//        Quiz quiz = new Quiz();
//        
//        // Set values using setters
////        quiz.setQuizId(101);
////        quiz.setTitle("Java Advance Quiz");
////        quiz.setCourseId("CSE102");
////        quiz.setDateScheduled("2025-04-26");
//
//        Session session=HibernateUtil.getSessionFactory().openSession();
//        Transaction tx=session.beginTransaction();
//        
//        try {
//        	// Save Quiz
//        	session.save(quiz);
//        	tx.commit();
//        	System.out.println("Quiz created with Id" + quiz.getQuizId());
//        }catch(Exception e) {
//        	tx.rollback();
//        	e.printStackTrace();
//        }finally {
//        	session.close();
//        }
//        
//        // Fetch all quizzes
////        session = HibernateUtil.getSessionFactory().openSession();
////        List<Quiz> quizzes=session.createQuery("From Quiz", Quiz.class).list();
////        System.out.println("All Quizzes");
////        for(Quiz q : quizzes) {
////        	System.out.println("Id" +q.getQuizId()+ "Title" +q.getTitle()+ "Date" +q.getDateScheduled());
////        }
////        session.close();
//        
//        session = HibernateUtil.getSessionFactory().openSession();
//        tx = session.beginTransaction();
//        
//        // Update quiz title
//        try {
//        	Quiz existingQuiz = session.get(Quiz.class, quiz.getQuizId());
//        	if(existingQuiz != null) {
//        		existingQuiz.setTitle("Updated Java Quiz");
//        		session.update(existingQuiz);
//        		tx.commit();
//        		System.out.println("Quiz title updated");
//        	}
//        }catch(Exception e) {
//        	tx.rollback();
//        	e.printStackTrace();
//        }finally {
//        	session.close();
//        }
//        
//        // Delete quiz
//        session = HibernateUtil.getSessionFactory().openSession();
//        tx = session.beginTransaction();
//        try {
//        	int quizIdToDelete = 5;
//        	Quiz quizToDelete = session.get(Quiz.class, quiz.getQuizId());
//        	quizToDelete.setQuizId(5);
//        	if(quizToDelete != null) {
//        		session.delete(quizToDelete);
//        		tx.commit();
//        		System.out.println("Quiz deleted");
//        	}
//        }catch(Exception e) {
//        	tx.rollback();
//        	e.printStackTrace();
//        }finally {
//        	session.close();
//        }
//    }
//}
