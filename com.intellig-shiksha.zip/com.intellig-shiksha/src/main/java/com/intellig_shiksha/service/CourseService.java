package com.intellig_shiksha.service;

import java.util.List;

import com.intellig_shiksha.entities.Course;

public interface CourseService {
	
	// Create a course 
	Course createCourse(Course course);
	
	// Get course by Id
	Course getCourseById(int courseId);
	
	// Get all course
	List<Course> getAllCourses();
	
	// Update and existing 
	Course updateCourse(Course course);
	
	// Delete course by Id
	void deleteCourse(int courseId);

}
