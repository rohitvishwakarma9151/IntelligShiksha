//package com.intellig_shiksha;
//
//import java.util.List;
//
//import com.intellig_shiksha.dao.AuthenticationDao;
//import com.intellig_shiksha.daoimpl.AuthenticationDaoImpl;
//import com.intellig_shiksha.entities.Authentication;
//
//public class MainAuthentication {
//
//    public static void main(String[] args) {
//        System.out.println("Authentication");
//
//        // Initialize DAO (which internally configures Hibernate)
//        AuthenticationDao authDao = new AuthenticationDaoImpl();
//
//        // Register a new user
////        Authentication newUser  = new Authentication();
////        newUser .setEmail("raj464@gmail.com");
////        newUser .setPassword("raj@123");
////        newUser .setRole("Student");
////        newUser .setReferenceId(23);
////
////        // Register the user and handle potential exceptions
////        try {
////            authDao.registerUser (newUser );
////            System.out.println("User  registered.");
////        } catch (Exception e) {
////            System.err.println("Error registering user: " + e.getMessage());
////        }
//
//        // Attempt login
//        Authentication loggedInUser  = authDao.login("raj464@gmail.com", "raj@123");
//        if (loggedInUser  != null) {
//            System.out.println("Login successful! Welcome, " + loggedInUser .getEmail());
//        } else {
//            System.out.println("Login failed. Invalid credentials.");
//        }
//
//        // Fetch all users
//        List<Authentication> users = authDao.getAllUsers();
//        System.out.println("All Registered Users:");
//        for (Authentication auth : users) {
//            System.out.println(" - Email: " + auth.getEmail() + ", Role: " + auth.getRole());
//        }
//
//        // Update user password
////        try {
////            authDao.updatePassword("raj464@gmail.com", "raj#321");
////            System.out.println("Password updated for raj464@gmail.com");
////        } catch (Exception e) {
////            System.err.println("Error updating password: " + e.getMessage());
////        }
//
//        // Delete user
//        try {
//            authDao.deleteUser ("rohan545@gmail.com");
//            System.out.println("User  deleted: rohan545@gmail.com");
//        } catch (Exception e) {
//            System.err.println("Error deleting user: " + e.getMessage());
//        }
//
//        System.out.println("Program completed.");
//    }
//}