package com.intellig_shiksha.dao;

import java.util.List;

import com.intellig_shiksha.entities.Authentication;

public interface AuthenticationDao {
	
	void registerUser(Authentication auth);

    Authentication login(String email, String password);

    void updatePassword(String email, String newPassword);

    void deleteUser(String email);

    Authentication getUserByEmail(String email);

    List<Authentication> getAllUsers();

}
