package com.intellig_shiksha.daoimpl;

import com.intellig_shiksha.dao.StudentDao;
import com.intellig_shiksha.entities.Students;
import com.intellig_shiksha.entities.Course;
import com.intellig_shiksha.util.HibernateUtil;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public abstract class StudentDaoImpl implements StudentDao {

    @Override
    public void addStudent(Students student) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.save(student);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public Students getStudentById(int studentId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Students.class, studentId);
        }
    }

    @Override
    public List<Students> getAllStudents() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Students> query = session.createQuery("FROM Students", Students.class);
            return query.getResultList();
        }
    }

    @Override
    public void updateStudent(Students student) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.update(student);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteStudent(int studentId) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Students student = session.get(Students.class, studentId);
            if (student != null) {
                tx = session.beginTransaction();
                session.delete(student);
                tx.commit();
            } else {
                System.out.println("Student not found with ID: " + studentId);
            }
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void enrollStudentToCourse(String email, String courseName) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();

            // Fetch the student by email
            Query<Students> studentQuery = session.createQuery("FROM Students WHERE email = :email", Students.class);
            studentQuery.setParameter("email", email);
            Students student = studentQuery.uniqueResult();

            // Fetch the course by course name
            Query<Course> courseQuery = session.createQuery("FROM Course WHERE courseName = :courseName", Course.class);
            courseQuery.setParameter("courseName", courseName);
            Course course = courseQuery.uniqueResult();

            if (student == null) {
                System.out.println("Student not found with email: " + email);
                if (tx != null) tx.rollback();
                return;
            }

            if (course == null) {
                System.out.println("Course not found with name: " + courseName);
                if (tx != null) tx.rollback();
                return;
            }

            // Set course and update student
            student.setCourse(course);
            student.setCourseEnrolled(course.getCourseName());
            session.update(student);

            tx.commit();
            System.out.println("Student enrolled to course successfully.");
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }
    
    
//    @Override
//    public void saveStudent(Students student) {
//        Transaction tx = null;
//        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
//            tx = session.beginTransaction();
//            session.save(student);
//            tx.commit();
//        } catch (Exception e) {
//            if (tx != null) tx.rollback();
//            e.printStackTrace();
//        }
//    }

    // Removed redundant saveStudent() method
    // Because addStudent() already does the same thing
}
